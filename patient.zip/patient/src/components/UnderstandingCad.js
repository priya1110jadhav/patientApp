import React from "react";
import "./UnderstandingCad.css"
import {
    FaArrowLeft,
    FaHome,
    FaBars,
  } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';

  
  const UnderstandingCad = () => {
    const navigate = useNavigate();

    return (
      <div className="mobile-frame">
        <header className="header">SM G9601</header>
        <nav className="navbar">
          <div className="navbar-left" onClick={()=> navigate("/education")}>
            <FaArrowLeft size={16} />
          </div>
          {/* <div className="navbar-title">UnderstandingCad</div> */}
        </nav>
        
        <div className="scrollable-cards-container">
          <div className="card1">
            <div className="card-content">              
              <h3 className="fontsss">UNDERSTANDING CAD</h3>
            </div>  
          </div>

          <div className="card2">
            <div className="card-content">              
            
            <iframe width="300" height="115" src="https://www.youtube.com/embed/ezTEc6GwLNs?si=0inF_QrI_RYEFzOy" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
            
            </div>            
          </div>

          <div className="card3">
            <div className="card-content1">              
              <p className="subtitle1">Lorem ipsum dolor sit amet,consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud xercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis ute irure dolor in reprehenderit in voluptate velit esse cillum </p>
            </div>
          </div>
        </div>
  
        <footer className="footer">
          <FaArrowLeft size={20} onClick={()=> navigate("/education")} />
          <FaHome size={20} />
          <FaBars size={20} />
        </footer>
      </div>
    );
  };
  
  export default UnderstandingCad;
  