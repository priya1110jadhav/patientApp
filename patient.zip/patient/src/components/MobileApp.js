import React from 'react';
import './MobileApp.css';
import { useNavigate } from 'react-router-dom';
import { FaArrowLeft, FaHome, FaBars, FaCalendarDay, FaRegCalendarAlt, FaChartLine, FaEllipsisH } from 'react-icons/fa';


const MobileApp = () => {
    const navigate = useNavigate();
  return (
    <div className="mobile-frame">
      <header className="header">
        SM G9601
      </header>
      <nav className="navbar">
        MY PLAN
      </nav>
      <div className="scrollable-cards-container">
        <div className="card">
          <div className="card-content">
            <img src="images/trackers.png" alt="Logo 1" className="card-logo" />
            <p className="title1">TRACKERS</p>
            <p className="subtitle">2 SELECTED</p>
          </div>
        </div>
        <div className="card" onClick={()=> navigate("/education")}>
          <div className="card-content">
            <img src="images/appointment.png" alt="Logo 2" className="card-logo" />
            <p className="title2">EDUCATION</p>
            <p className="subtitle">2 SELECTED</p>
          </div>
        </div>
        <div className="card">
          <div className="card-content">
            <img src="images/education.png" alt="Logo 3" className="card-logo" />
            <p className="title3">APPOINTMENT</p>
            <p className="subtitle">2 SELECTED</p>
          </div>
        </div>
      </div>
      <div className="bottom-nav">
        <div className="bottom-nav-item">
          <FaCalendarDay size={20} />
          <span>Today</span>
        </div>
        <div className="bottom-nav-item plan">
          <FaRegCalendarAlt size={20} />
          <span>Plan</span>
        </div>
        <div className="bottom-nav-item ">
          <FaChartLine size={20} />
          <span>Trends</span>
        </div>
        <div className="bottom-nav-item">
          <FaEllipsisH size={20} />
          <span>More</span>
        </div>
      </div>
      <footer className="footer">
        <FaArrowLeft size={20} />
        <FaHome size={20} />
        <FaBars size={20} />
      </footer>
    </div>
  );
}

export default MobileApp;
