import React from "react";
import "./Education.css";
import { useNavigate } from 'react-router-dom';

import {
  FaArrowLeft,
  FaHome,
  FaBars,
} from "react-icons/fa";

const Education = () => {
    const navigate = useNavigate();
  return (
    <div className="mobile-frame">
      <header className="header">SM G9601</header>
      <nav className="navbar">
        <div className="navbar-left" onClick={()=> navigate("/")}>
          <FaArrowLeft size={16} />
        </div>
        <div className="navbar-title">EDUCATION</div>
      </nav>
      <nav className="navbar2">
        <p className="current">CURRENT</p>
        <p className="library">LIBRARY</p>
      </nav>
      <div className="scrollable-cards-container">
        <div className="card" onClick={()=> navigate("/understandingCad")}>
          <div className="card-content">
            <p className="title1">UNDERSTANDING ARIAL FIBRILLATION</p>
            <p className="subtitle">UNDERSTANGING CAD</p>
          </div>
        </div>
        <div className="card">
          <div className="card-content">
            <p className="title1">MANAGE YOUR MEDICATIONS</p>
            <p className="subtitle">QUESTIONS TO ASK ABOUT YOUR MEDICATIONS</p>
          </div>
        </div>
        <div className="card">
          <div className="card-content">
            <p className="title1">HEAR HEALTH</p>
            <p className="subtitle">WHAT IS CARDIAC REHABILATION</p>
          </div>
        </div>
      </div>

      <footer className="footer">
        <FaArrowLeft size={20} onClick={()=> navigate("/")}/>
        <FaHome size={20} />
        <FaBars size={20} />
      </footer>
    </div>
  );
};

export default Education;
