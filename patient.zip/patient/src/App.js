import React from 'react';
import MobileApp from './components/MobileApp';
import Education from './components/Education';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import UnderstandingCad from './components/UnderstandingCad';


function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<MobileApp/>}/>
          <Route path="/education" element={<Education/>}/>
          <Route path="/understandingCad" element={<UnderstandingCad/>}/>
        </Routes>
        {/* <UnderstandingCad/> */}
      </div>
    </Router>
  );
}

export default App;
