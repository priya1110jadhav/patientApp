import React from "react";
import "./UnderstandingCad.css"
import {
    FaArrowLeft,
    FaHome,
    FaBars,
  } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';

  
  const UnderstandingCad = () => {
    const navigate = useNavigate();

    return (
      <div className="mobile-frame">
        <header className="header">SM G9601</header>
        <nav className="navbar">
          <div className="navbar-left" onClick={()=> navigate("/education")}>
            <FaArrowLeft size={16} />
          </div>
          {/* <div className="navbar-title">UnderstandingCad</div> */}
        </nav>
        
        <div className="scrollable-cards-container">
          <div className="card1">
            <div className="card-content">              
              <p className="fontsss">UNDERSTANDING ATRIAL FIBRILLATION</p>
            </div>  
          </div>

          <div className="card2">
            <div className="card-content">              
            
            <iframe width="300" height="115" src="https://www.youtube.com/embed/ezTEc6GwLNs?si=0inF_QrI_RYEFzOy" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
            
            </div>            
          </div>

          <div className="card3">
            <div className="card-content1">              
              <p className="subtitle1"><span style={{color: "blue"}}>Overview</span></p>
              <p className="textformat">Your heart’s electrical system tells your heart when to contract and pump blood to the rest of your body in a regular and organized way. With AFib, these electrical impulses become jumbled – think of it as a short circuit in a sense. As a result, the heart beats irregularly.

AFib is sometimes called a quivering heart.<br></br> <br></br>That’s because the two upper parts of the heart (called the atria) spasm. When this happens, the normal communication between the upper and lower chambers of the heart is disrupted and becomes very jumbled.

Because of this, many people with AFib can feel very tired and zapped of energy. If you have AFib, you may notice being out of breath simply walking up one flight of stairs, especially if your heart rate is very fast. That’s because you may not be getting enough oxygen; the heart isn’t able to squeeze enough nutrient-rich blood out to the body.

If you have AFib, you’re not alone. It’s the most common type of irregular heartbeat, affecting up to 6 million people in the U.S. Treating AFib can lower the chance of serious problems like stroke and heart failure.

AFib has often been defined by how often an irregular rhythm occurs and whether it stops on its own. For example:
<br></br><br></br>
<span style={{color: "blue"}}>Paroxysmal:</span> Comes and goes and usually stops on its own.<br></br>
<span style={{color: "blue"}}>Persistent:</span> Lasts over 1 week or sometimes longer and should be treated.<br></br>
<span style={{color: "blue"}}>Permanent:</span> The heart’s normal rhythm can’t be restored.<br></br><br></br>
AFib is now also described and grouped into stages to highlight prevention and what treatments might be most helpful when. Some examples include deciding on lifestyle changes to help lower your risk, screening and therapies.

AFib and Stroke

Because your heartbeat is out of sync, your heart has a harder time pumping blood out of the body. When this happens, blood can pool in the heart and form blood clots. If a blood clot from the heart travels through the bloodstream to the brain, it can cause a stroke. Strokes related to AFib tend to be more severe and deadly than other types of strokes.
<br></br>
<span style={{color: "blue"}}>What is Atrial Fibrillation?</span><br></br>

Atrial fibrillation is a problem with the rate or rhythm of the heartbeat that causes the heart to beat quickly or irregularly. Learn about symptoms of atrial fibrillation, or AFib, and how they may be treated.</p>
            </div>
          </div>
        </div>
  
        <footer className="footer">
          <FaArrowLeft size={20} onClick={()=> navigate("/education")} />
          <FaHome size={20} />
          <FaBars size={20} />
        </footer>
      </div>
    );
  };
  
  export default UnderstandingCad;
  